DROP DATABASE IF EXISTS `sequelize_library`;
CREATE DATABASE `sequelize_library`;
